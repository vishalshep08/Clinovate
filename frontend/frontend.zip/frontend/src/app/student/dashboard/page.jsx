"use client";
import StudentDashboard from "@/components/StudentDashboard";

export default function StudentDashboardPage() {
  // (Optional) If you want, add auth check here later.
  return <StudentDashboard />;
}
